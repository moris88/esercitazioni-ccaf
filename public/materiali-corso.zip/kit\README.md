# Kit delle esercitazioni CCA-F

File pronti per le esercitazioni. Non serve programmare: i passi sono in "Esercitazioni_pratiche.pdf",
la preparazione del computer in "Guida_setup_e_avvio.pdf".

| Cartella | Contenuto | Come si usa | Serve per |
| --- | --- | --- | --- |
| dati/ | Fattura e schema, email, fonti, caso cliente | Si allega in chat | P·7, D4·1, D4·2, D5·1, D5·3 |
| claude-code/ | Hook, regola, skill, subagente | Lo copia Claude, su richiesta | D1·3, D3·1, D3·2 |

Tenete `kit` accanto a `cartella-prova`: i passi usano percorsi come `../kit/...`.
Su Windows l'hook di D1·3 richiede Git for Windows.
