---
name: spiega-procedura
description: Spiega una procedura aziendale a chi la legge per la prima volta. Usala quando qualcuno chiede come funziona una procedura o cosa prevede un documento della cartella procedure.
argument-hint: [percorso della procedura]
allowed-tools: Read, Grep, Glob
---
# Spiega una procedura

Spiega la procedura $ARGUMENTS con questa struttura:

1. **A cosa serve**, in una frase.
2. **Chi la segue**: il responsabile, se è indicato.
3. **I passaggi**, in ordine.
4. **Documenti collegati**: cerca se altre procedure parlano dello stesso tema.
5. **Un dubbio o una contraddizione** da segnalare.

Non modificare nessun file.
