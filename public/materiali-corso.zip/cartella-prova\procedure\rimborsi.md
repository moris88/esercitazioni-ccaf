# Rimborsi

Responsabile: Ufficio clienti
Ultima revisione: 10/09/2026

1. Il cliente può chiedere il rimborso entro 14 giorni dalla consegna.
2. Fino a 100 euro il rimborso è automatico.
3. Sopra i 100 euro serve l'approvazione di un responsabile.
