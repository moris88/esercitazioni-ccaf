# Garanzie

Ultima revisione: 15/06/2026

1. La garanzia dura 24 mesi dalla data di acquisto.
2. Per i prodotti arrivati danneggiati il cliente può chiedere il rimborso entro 30 giorni dalla consegna.
3. Serve sempre una foto del danno.
