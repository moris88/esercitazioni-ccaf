#!/usr/bin/env bash
# Hook PreToolUse (esercitazione D1·3). Non serve leggerlo né modificarlo.
# Riceve la richiesta di Claude: uscita 2 = bloccata, uscita 0 = nessuna obiezione.
evento=$(cat)
richiesta=${evento#*'"tool_input":'}

# Se la richiesta non è leggibile, nel dubbio blocca
if [ "$richiesta" = "$evento" ]; then
  echo "Bloccato dall'hook: richiesta illeggibile." >&2
  exit 2
fi

if grep -qi 'riservato' <<<"$richiesta"; then
  echo "Bloccato dall'hook: la cartella riservato non si può toccare." >&2
  exit 2
fi

if grep -q '"command"' <<<"$richiesta" && grep -qiE '\b(rm|rmdir|rd|del|unlink|Remove-Item)\b|-delete' <<<"$richiesta"; then
  echo "Bloccato dall'hook: cancellare file non è permesso." >&2
  exit 2
fi

exit 0
