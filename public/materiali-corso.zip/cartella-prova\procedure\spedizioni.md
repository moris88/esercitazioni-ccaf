# Spedizioni

Responsabile: Magazzino
Ultima revisione: 02/03/2024

1. Gli ordini confermati entro le 14:00 partono il giorno stesso.
2. La consegna standard richiede da 2 a 4 giorni lavorativi.
3. Se il pacco è in ritardo di oltre 7 giorni si apre una segnalazione al corriere.
