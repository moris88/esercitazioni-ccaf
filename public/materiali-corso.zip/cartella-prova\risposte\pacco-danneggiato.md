Gentile cliente,

ci dispiace per il danno. Ci invii una foto del prodotto e procederemo con la verifica.

Cordiali saluti,
Il servizio clienti
