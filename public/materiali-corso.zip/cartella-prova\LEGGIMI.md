# Cartella di prova

Documenti inventati di un negozio online, per le esercitazioni del corso CCA-F. Nessun dato è reale.

Come si usa: copiate insieme le cartelle `cartella-prova` e `kit`, una accanto all'altra. Aprite il terminale in
`cartella-prova` e scrivete `claude`. Se qualcosa si rovina, ricopiate la cartella originale.
