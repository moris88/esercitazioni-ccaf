---
paths:
  - "risposte/**"
---
# Regole per le risposte ai clienti

- Inizia sempre con "Gentile cliente,".
- Massimo 5 righe di testo.
- Non promettere mai una data di consegna.
- Chiudi sempre con "Cordiali saluti, Il servizio clienti".
